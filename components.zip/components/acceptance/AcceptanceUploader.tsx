// 📁 檔案路徑：components/acceptance/AcceptanceUploader.tsx

'use client';

import { useEffect, useState } from 'react';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import {
  collection,
  addDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  getDocs,
  query,
  where,
  orderBy,
  updateDoc,
} from 'firebase/firestore';
import { auth, db, storage } from '@/libs/firebase';
import html2pdf from 'html2pdf.js';
import { v4 as uuidv4 } from 'uuid';
import toast from 'react-hot-toast';
import AcceptanceImageCard from './AcceptanceImageCard';

const fakeCategories = ['木作', '水電', '油漆', '泥作', '其他'];

interface RecordItem {
  id: string;
  filename: string;
  url: string;
  note: string;
  type: string;
  sortIndex: number;
}

export default function AcceptanceUploader({ quoteId }: { quoteId?: string }) {
  const [files, setFiles] = useState<FileList | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [types, setTypes] = useState<Record<string, string>>({});
  const [records, setRecords] = useState<RecordItem[]>([]);
  const [uploading, setUploading] = useState(false);

  // 🚀 初始化 - 讀取該報價單下所有驗收資料
  useEffect(() => {
    const fetchData = async () => {
      if (!quoteId) return;
      const q = query(
        collection(db, 'acceptanceRecords'),
        where('quoteId', '==', quoteId),
        orderBy('sortIndex', 'asc')
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        filename: doc.data().filename,
        url: doc.data().url,
        note: doc.data().note,
        type: doc.data().type,
        sortIndex: doc.data().sortIndex || 0,
      }));
      setRecords(data);
    };
    fetchData();
  }, [quoteId]);

  const handleNoteChange = (name: string, value: string) => {
    setNotes((prev) => ({ ...prev, [name]: value }));
  };

  const handleTypeChange = (name: string, value: string) => {
    setTypes((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFiles(e.target.files);
  };

  const handleUpload = async () => {
    if (!files || !auth.currentUser) return toast.error('請先登入並選擇圖片');
    setUploading(true);
    const uid = auth.currentUser.uid;

    try {
      const newRecords: RecordItem[] = [];

      for (const file of Array.from(files)) {
        const storageRef = ref(storage, `acceptance/${uid}/${Date.now()}-${file.name}`);
        await uploadBytes(storageRef, file);
        const downloadURL = await getDownloadURL(storageRef);
        const docRef = await addDoc(collection(db, 'acceptanceRecords'), {
          uid,
          quoteId: quoteId || null,
          filename: file.name,
          url: downloadURL,
          note: notes[file.name] || '',
          type: types[file.name] || '其他',
          status: 'pending',
          signed: false,
          sortIndex: Date.now(),
          createdAt: serverTimestamp(),
        });

        newRecords.push({
          id: docRef.id,
          filename: file.name,
          url: downloadURL,
          note: notes[file.name] || '',
          type: types[file.name] || '其他',
          sortIndex: Date.now(),
        });
      }

      setRecords((prev) => [...prev, ...newRecords]);
      setFiles(null);
      setNotes({});
      setTypes({});
      toast.success('上傳完成 ✅');
    } catch (err) {
      console.error(err);
      toast.error('上傳失敗');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string, url: string) => {
    try {
      const fileRef = ref(storage, url);
      await deleteObject(fileRef);
      await deleteDoc(doc(db, 'acceptanceRecords', id));
      setRecords((prev) => prev.filter((item) => item.id !== id));
      toast.success('圖片已刪除');
    } catch (err) {
      console.error(err);
      toast.error('刪除失敗');
    }
  };

  const exportPDF = () => {
    const container = document.getElementById('pdf-report');
    if (!container) return;

    html2pdf()
      .set({
        margin: 10,
        filename: `驗收報告_${quoteId}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      })
      .from(container)
      .save();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">📸 驗收照片上傳</h2>

      <input
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileChange}
        className="border p-2 rounded"
      />

      {files &&
        Array.from(files).map((file) => (
          <div key={file.name} className="border p-2 rounded bg-gray-50">
            <div className="font-semibold text-sm">{file.name}</div>
            <textarea
              className="w-full border p-2 rounded mt-1 text-sm"
              placeholder="備註..."
              value={notes[file.name] || ''}
              onChange={(e) => handleNoteChange(file.name, e.target.value)}
            />
            <select
              className="w-full border p-2 rounded mt-2 text-sm"
              value={types[file.name] || ''}
              onChange={(e) => handleTypeChange(file.name, e.target.value)}
            >
              <option value="">選擇分類</option>
              {fakeCategories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        ))}

      <button
        onClick={handleUpload}
        disabled={uploading}
        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
      >
        {uploading ? '上傳中...' : '確認上傳'}
      </button>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
        {records.map((item) => (
          <AcceptanceImageCard
            key={item.id}
            url={item.url}
            filename={item.filename}
            note={item.note}
            type={item.type}
            onDelete={() => handleDelete(item.id, item.url)}
          />
        ))}
      </div>

      {records.length > 0 && (
        <>
          <button
            onClick={exportPDF}
            className="mt-6 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            匯出驗收報告 PDF
          </button>

          <div id="pdf-report" className="p-4 border mt-4 bg-white">
            <h3 className="text-base font-bold mb-2">📄 驗收報告</h3>
            {records.map((item, i) => (
              <div key={i} className="mb-4 border-b pb-4">
                <div className="text-sm font-semibold">📌 分類：{item.type}</div>
                <img
                  src={item.url}
                  alt={`驗收照片 ${i}`}
                  className="mt-2 w-64 h-auto border rounded"
                />
                <div className="mt-2 text-sm">📝 備註：{item.note}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
