'use client';

import { useState } from 'react';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, storage } from '@/libs/firebase';
import html2pdf from 'html2pdf.js';

const categories = ['木作', '水電', '油漆', '泥作', '其他'];

export default function PhotoUploaderWithReport() {
  const [files, setFiles] = useState<FileList | null>(null);
  const [notes, setNotes] = useState<{ [key: string]: string }>({});
  const [types, setTypes] = useState<{ [key: string]: string }>({});
  const [uploading, setUploading] = useState(false);
  const [uploadedRecords, setUploadedRecords] = useState<any[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFiles(e.target.files);
  };

  const handleNoteChange = (name: string, value: string) => {
    setNotes((prev) => ({ ...prev, [name]: value }));
  };

  const handleTypeChange = (name: string, value: string) => {
    setTypes((prev) => ({ ...prev, [name]: value }));
  };

  const handleUpload = async () => {
    if (!files || !auth.currentUser) return;
    setUploading(true);

    const uid = auth.currentUser.uid;
    const newRecords = [];

    for (const file of Array.from(files)) {
      const storageRef = ref(storage, `acceptance/${uid}/${Date.now()}-${file.name}`);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);

      const data = {
        uid,
        filename: file.name,
        url: downloadURL,
        note: notes[file.name] || '',
        type: types[file.name] || '其他',
        createdAt: serverTimestamp(),
      };

      await addDoc(collection(db, 'acceptanceRecords'), data);
      await addDoc(collection(db, 'calendarTasks'), {
        uid,
        title: `驗收：${file.name}`,
        category: data.type,
        description: data.note,
        start: new Date().toISOString(),
        allDay: true,
        createdAt: serverTimestamp(),
      });

      newRecords.push({ ...data, url: downloadURL, localNote: data.note });
    }

    setUploadedRecords(newRecords);
    setFiles(null);
    setNotes({});
    setTypes({});
    setUploading(false);
    alert('上傳完成 ✅');
  };

  const exportPDF = () => {
    const container = document.getElementById('pdf-report');
    if (!container) return;

    html2pdf()
      .set({
        margin: 10,
        filename: 'acceptance-report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      })
      .from(container)
      .save();
  };

  return (
    <div className="p-4 bg-white rounded shadow-md w-full max-w-4xl">
      <h2 className="text-lg font-semibold mb-4">📸 驗收照片上傳 × 報告產出</h2>

      <input
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileChange}
        className="mb-4"
      />

      {files &&
        Array.from(files).map((file) => (
          <div key={file.name} className="mb-4 border rounded p-2">
            <div className="font-medium text-sm">{file.name}</div>
            <textarea
              placeholder="輸入照片備註..."
              className="w-full border p-2 rounded text-sm mt-1"
              value={notes[file.name] || ''}
              onChange={(e) => handleNoteChange(file.name, e.target.value)}
            />
            <select
              value={types[file.name] || ''}
              onChange={(e) => handleTypeChange(file.name, e.target.value)}
              className="mt-2 border p-1 rounded text-sm"
            >
              <option value="">選擇分類</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        ))}

      <button
        onClick={handleUpload}
        disabled={uploading}
        className="mt-2 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50"
      >
        {uploading ? '上傳中...' : '上傳驗收資料'}
      </button>

      {/* ✅ 匯出區塊 */}
      {uploadedRecords.length > 0 && (
        <div className="mt-6">
          <button
            onClick={exportPDF}
            className="mb-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            匯出驗收報告 PDF
          </button>

          <div id="pdf-report" className="p-4 bg-white border rounded">
            <h3 className="text-base font-bold mb-2">📄 驗收報告</h3>
            {uploadedRecords.map((item, i) => (
              <div key={i} className="mb-4 border-b pb-4">
                <div className="text-sm font-semibold">📌 分類：{item.type}</div>
                <img
                  src={item.url}
                  alt={`照片-${i}`}
                  className="mt-2 w-64 h-auto border rounded"
                />
                <div className="mt-2 text-sm">📝 備註：{item.localNote}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
