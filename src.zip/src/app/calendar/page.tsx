import CalendarViewPro from '@/components/calendar/CalendarViewPro';

export default function CalendarPage() {
  return (
    <main className="p-4">
      <CalendarViewPro />
    </main>
  );
}
